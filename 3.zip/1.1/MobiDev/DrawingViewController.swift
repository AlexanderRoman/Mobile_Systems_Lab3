//
//  DrawingViewController.swift
//  MobiDev
//
//  Created by Cockerman on 23.04.2021.
//

import UIKit

class DrawingViewController: UIViewController {    
    @IBOutlet var DrawingUIView: DrawingUIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }

}
