//
//  ListViewController.swift
//  MobiDev
//
//  Created by Cockerman on 25.04.2021.
//

import UIKit


class ListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource  {
       
    private var myTableView: UITableView!
    var bookArr = [Book]()
    var numOfBooks = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let filePath = Bundle.main.path(forResource: "BooksList", ofType: "txt")
        var text = ""
        text = try! String(contentsOfFile: filePath!)
        
        let tempArr = text.components(separatedBy: "{")
        numOfBooks = tempArr.count - 2
        
        var textArr = text.components(separatedBy: CharacterSet(charactersIn: "[{\"]"))
        
        var iterator = 0
        while iterator < textArr.count{
            if textArr[iterator] == "" || textArr[iterator] == " "{
                textArr.remove(at: iterator)
                iterator -= 1
            }
            iterator += 1
        }
        textArr.remove(at: 0)
        textArr.remove(at: 0)
        textArr.remove(at: textArr.count-1)
        iterator = 0
        
        
        //Parsing through txt file and setting the entity properties right away
        func propertySetter(book: Book){
                if textArr[iterator] == "title"{
                    if textArr[iterator + 2] != ","{
                        book.title = textArr[iterator + 2]
                        iterator += 4
                    }else{ book.title = "No title"; iterator += 3 }
                }
                if textArr[iterator] == "subtitle"{
                    if textArr[iterator + 2] != ","{
                        book.subtitle = textArr[iterator + 2]
                        iterator += 4
                    }else{ book.subtitle = "No subtitle"; iterator += 3 }
                }
                if textArr[iterator] == "isbn13"{
                    if textArr[iterator + 2] != ","{
                        book.isbn13 = textArr[iterator + 2]
                        iterator += 4
                    }else{ book.isbn13 = "No isbn13"; iterator += 3 }
                }
                if textArr[iterator] == "price"{
                    if textArr[iterator + 2] != ","{
                        book.price = textArr[iterator + 2]
                        iterator += 4
                    }else{ book.price = "No price"; iterator += 3 }
                }
                if textArr[iterator] == "image"{
                    if textArr[iterator + 2] != "},"{
                        book.image = textArr[iterator + 2]
                        iterator += 4
                    }else{ book.image = "No image"; iterator += 3 }
                }
        }
    
        // Creating entities with some spare ones for further expansion. This is optimal as you can't put a variable in another variables name
        let book1 = Book(); let book2 = Book(); let book3 = Book(); let book4 = Book(); let book5 = Book(); let book6 = Book(); let book7 = Book(); let book8 = Book(); let book9 = Book(); let book10 = Book(); let book11 = Book(); let book12 = Book(); let book13 = Book(); let book14 = Book(); let book15 = Book(); let book16 = Book();
        bookArr = [book1, book2, book3, book4, book5, book6, book7, book8, book9, book10, book11, book12, book13, book14, book15, book16]
        
        var j = 0
        while j < numOfBooks {
            propertySetter(book: bookArr[j])
            j += 1
        }
                                
        
        //TableView:
        let barHeight: CGFloat = UIApplication.shared.statusBarFrame.size.height
        let displayWidth: CGFloat = self.view.frame.width
        let displayHeight: CGFloat = self.view.frame.height

        
        myTableView = UITableView(frame: CGRect(x: 0, y: barHeight, width: displayWidth, height: displayHeight - barHeight))
        myTableView.register(UITableViewCell.self, forCellReuseIdentifier: "MyCell")
        myTableView.dataSource = self
        myTableView.delegate = self
        self.view.addSubview(myTableView)
        myTableView.translatesAutoresizingMaskIntoConstraints = false
        myTableView.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
        myTableView.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        myTableView.rightAnchor.constraint(equalTo: view.rightAnchor).isActive = true
        myTableView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
        self.myTableView.rowHeight = UITableView.automaticDimension
    }

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return numOfBooks
    }

    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath as IndexPath)
        let margineGuide = cell.contentView.layoutMarginsGuide
        
        //LABEL
        let textLabel: UILabel = UILabel()
        if bookArr[indexPath.row].subtitle != "No subtitle"{
            textLabel.text = bookArr[indexPath.row].title + "\n\n" + bookArr[indexPath.row].subtitle + "\n\n" + bookArr[indexPath.row].price
        }else{
            textLabel.text = bookArr[indexPath.row].title + "\n\n" + bookArr[indexPath.row].price
        }
        textLabel.font = cell.textLabel!.font.withSize(12.0)
        textLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        textLabel.numberOfLines = 10
        
        cell.contentView.addSubview(textLabel)
        textLabel.translatesAutoresizingMaskIntoConstraints = false
        
        textLabel.trailingAnchor.constraint(equalTo: margineGuide.trailingAnchor).isActive = true
        textLabel.topAnchor.constraint(equalTo: margineGuide.topAnchor).isActive = true
        textLabel.bottomAnchor.constraint(equalTo: margineGuide.bottomAnchor).isActive = true

        //IMAGE
        let imageView: UIImageView = UIImageView()
        if bookArr[indexPath.row].image != "No image"{
            imageView.image = UIImage(named: bookArr[indexPath.row].image)
        }
        cell.contentView.addSubview(imageView)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.leadingAnchor.constraint(equalTo: margineGuide.leadingAnchor).isActive = true
        imageView.trailingAnchor.constraint(equalTo: textLabel.leadingAnchor).isActive = true
        imageView.centerYAnchor.constraint(equalTo: margineGuide.centerYAnchor).isActive = true
        imageView.heightAnchor.constraint(equalToConstant: 100.0).isActive = true
        imageView.widthAnchor.constraint(equalToConstant: 77.0).isActive = true
                        
        return cell
        
    }
}

